import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import os
import datetime
from graphviz import Digraph

def generate_graph():
    # Define nodes
    cdm = "Customer Data Management Role (CDM)"
    adr = "Analytics Dashboard Role (ADR)"
    admin = "Administrator Role (Admin)"
    alice = "Alice"
    bob = "Bob"
    carol = "Carol"
    david = "David"
    eve = "Eve"
    no_covert_channel = "No Covert Channel Found"

    # Define edges
    edges = [
        (alice, cdm),
        (alice, adr),
        (bob, cdm),
        (carol, admin),
        (david, adr),
        (eve, cdm),
    ]

    # Create Digraph object
    dot = Digraph(comment="AWS IAM Policy Graph")

    # Add nodes
    dot.node(cdm, shape="rectangle")
    dot.node(adr, shape="rectangle")
    dot.node(admin, shape="rectangle")
    dot.node(alice, shape="ellipse")
    dot.node(bob, shape="ellipse")
    dot.node(carol, shape="ellipse")
    dot.node(david, shape="ellipse")
    dot.node(eve, shape="ellipse")
    dot.node(no_covert_channel, shape="rectangle", style="filled", color="lightblue")

    # Add edges
    for i, edge in enumerate(edges):
        dot.edge(edge[0], edge[1], label=str(i+1))

    # Set graph attributes
    dot.attr(rankdir="LR")

    # Save graph as dot, pdf and png files
    now = datetime.datetime.now().strftime("%d%b%y_%H%M%S")
    file_name = f"AWS_IAM_Policy_Graph_{now}"
    dot.format = "pdf"
    dot.render(file_name, directory="D:\TCS\FOC\AWS Paper Runs\Output", view=True)

try:
    generate_graph()
except Exception as e:
    print(e)
