import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
import graphviz

def create_graph():
    dot = graphviz.Digraph()
    dot.node('Initiator_Alice', shape='ellipse')
    dot.node('Initiator_Bob', shape='ellipse')
    dot.node('Manager_Carol', shape='ellipse')
    dot.node('S3_datasync_storage', shape='box')
    dot.node('Transfer_Initiation_Role', shape='box')
    dot.node('Data_Management_API_Role', shape='box')
    dot.node('Viewer_Role', shape='box')

    dot.edge('Initiator_Alice', 'Transfer_Initiation_Role')
    dot.edge('Initiator_Alice', 'Viewer_Role')
    dot.edge('Initiator_Bob', 'Transfer_Initiation_Role')
    dot.edge('Initiator_Bob', 'Viewer_Role')
    dot.edge('Manager_Carol', 'Data_Management_API_Role')
    dot.edge('Manager_Carol', 'Viewer_Role')
    dot.edge('Transfer_Initiation_Role', 'Data_Management_API_Role', style='dotted')

    dot.edge('Transfer_Initiation_Role', 'S3_datasync_storage', color='yellow', label='covert channel')
    dot.edge('Viewer_Role', 'S3_datasync_storage')

    # Save the output files in the given directory
    output_directory = 'D:/TCS/FOC/AWS Paper Runs/Output/'
    timestamp = datetime.datetime.now().strftime('%d%b%y_%H%M%S')
    filename = output_directory + 'data_sync_vulnerability_' + timestamp
    try:
        dot.render(filename, view=True, format='png')
    except Exception as e:
        print(f'Error generating graph: {str(e)}')


if __name__ == "__main__":
    create_graph()
