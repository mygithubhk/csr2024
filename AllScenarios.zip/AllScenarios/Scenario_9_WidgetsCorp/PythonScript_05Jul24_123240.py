import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
import sys
from graphviz import Digraph

# Folder to save the output files
output_folder = "D:\\TCS\\FOC\\AWSRuns\\Output\\"

# Current date and time
current_time = datetime.datetime.now()
formatted_time = current_time.strftime("%d%b%y_%H%M%S")

# Output file names
output_base_filename = f"AccessGraph_{formatted_time}"
dot_filename = os.path.join(output_folder, output_base_filename + ".dot")
pdf_filename = os.path.join(output_folder, output_base_filename + ".pdf")
png_filename = os.path.join(output_folder, output_base_filename + ".png")

try:
    # Initialize Digraph object
    dot = Digraph(comment='AWS Access Graph')

    # Define the graph nodes for principals, roles, and resources
    dot.node('Alice', 'Alice\n(Data Entry Clerk)')
    dot.node('Bob', 'Bob\n(Data Entry Clerk)')
    dot.node('Charlie', 'Charlie\n(Data Analyst)')
    dot.node('Dave', 'Dave\n(Data Analyst)')
    dot.node('Eve', 'Eve\n(Data Scientist)')
    dot.node('Frank', 'Frank\n(Data Scientist)')
    dot.node('Grace', 'Grace\n(Financial Auditor)')
    dot.node('Henry', 'Henry\n(Financial Auditor)')
    dot.node('Ian', 'Ian\n(Senior Manager)')
    dot.node('Jessica', 'Jessica\n(Senior Manager)')

    # Define the graph nodes for roles
    dot.node('DataEntryClerkRole', 'DataEntryClerkRole')
    dot.node('DataAnalystRole', 'DataAnalystRole')
    dot.node('DataScientistRole', 'DataScientistRole')
    dot.node('FinancialAuditorRole', 'FinancialAuditorRole')
    dot.node('SeniorManagerRole', 'SeniorManagerRole')

    # Define the graph nodes for resources
    dot.node('DataEntry', 'Data Entry\nS3 Bucket')
    dot.node('AnonymizedData', 'Anonymized Data\nS3 Bucket')
    dot.node('RawData', 'Raw Data\nS3 Bucket')
    dot.node('FinancialData', 'Financial Data\nS3 Bucket')

    # Define edges for role to resource access
    dot.edges([('DataEntryClerkRole', 'DataEntry')])
    dot.edges([('DataAnalystRole', 'AnonymizedData')])
    dot.edges([('DataScientistRole', 'AnonymizedData'), ('DataScientistRole', 'RawData')])
    dot.edges([('FinancialAuditorRole', 'FinancialData')])

    # Define edges for principals to their roles
    dot.edges([('Alice', 'DataEntryClerkRole'), ('Bob', 'DataEntryClerkRole')])
    dot.edges([('Charlie', 'DataAnalystRole'), ('Dave', 'DataAnalystRole')])
    dot.edges([('Eve', 'DataScientistRole'), ('Frank', 'DataScientistRole')])
    dot.edges([('Grace', 'FinancialAuditorRole'), ('Henry', 'FinancialAuditorRole')])
    dot.edges([('Ian', 'SeniorManagerRole'), ('Jessica', 'SeniorManagerRole')])

    # Define edges for role assumptions (1, 2, 3 denote the order of assumption)
    dot.edge('DataEntryClerkRole', 'DataAnalystRole', label='1')
    dot.edge('DataAnalystRole', 'DataScientistRole', label='2')
    dot.edge('DataScientistRole', 'FinancialAuditorRole', label='3')

    # Add a rectangle with a message at the top
    dot.attr('node', shape='rectangle', style='filled', color='lightblue2')
    dot.node('NoCovertChannel', 'No Covert Channel Found')

    # Generate the output files
    dot.save(dot_filename)  # Save the dot source to a file
    dot.render(pdf_filename, format='pdf', cleanup=False)  # Generate a PDF
    dot.render(png_filename, format='png', cleanup=False)  # Generate a PNG

    # Open the PNG image
    os.startfile(png_filename)

except Exception as e:
    print(e)
