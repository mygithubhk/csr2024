import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
from graphviz import Digraph

def generate_graph():
    dot = Digraph()
    dot.node('ContractorRole', 'ContractorRole')
    dot.node('DataAnalystRole', 'DataAnalystRole')
    dot.node('SeniorDataScientistRole', 'SeniorDataScientistRole')
    dot.node('FinanceTeamRole', 'FinanceTeamRole')
    dot.node('SeniorManagerRole', 'SeniorManagerRole')
    
    # ContractorRole
    dot.edge('ContractorRole', 'complexco-public')
    dot.edge('ContractorRole', 'DataAnalystRole')
    dot.edge('ContractorRole', 'FinanceManagerRole')
    
    # DataAnalystRole
    dot.edge('DataAnalystRole', 'complexco-anonymized-data')
    dot.edge('DataAnalystRole', 'SeniorDataScientistRole')
    
    # SeniorDataScientistRole
    dot.edge('SeniorDataScientistRole', 'complexco-anonymized-data')
    dot.edge('SeniorDataScientistRole', 'complexco-raw-data')
    dot.edge('SeniorDataScientistRole', 'FinanceTeamRole', style='dotted')
    dot.edge('SeniorDataScientistRole', 'SeniorManagerRole', style='dotted')
    
    # FinanceTeamRole
    dot.edge('FinanceTeamRole', 'complexco-financial-data')
    dot.edge('FinanceTeamRole', 'SeniorManagerRole')
    
    # SeniorManagerRole
    dot.edge('SeniorManagerRole', 'complexco-anonymized-data')
    dot.edge('SeniorManagerRole', 'complexco-raw-data')
    dot.edge('SeniorManagerRole', 'complexco-financial-data')
    
    # Role Chaining
    dot.edge('ContractorRole', 'DataAnalystRole', style='dotted', constraint='false')
    dot.edge('DataAnalystRole', 'SeniorDataScientistRole', style='dotted', constraint='false')
    dot.edge('SeniorDataScientistRole', 'FinanceTeamRole', style='dotted', constraint='false')
    dot.edge('FinanceTeamRole', 'SeniorManagerRole', style='dotted', constraint='false')
    
    # Covert Channel
    dot.edge('ContractorRole', 'complexco-financial-data', color='yellow', label='covert channel')
    
    dot.attr(label=r'\n\nComplexCo AWS Policy Violation Graph\n\n', fontsize='20')
    dot.format = 'pdf'
    output_file_name = 'D:\\TCS\\FOC\\AWSRuns\\Output\\complexco-aws-policy-violation-graph-' + datetime.datetime.now().strftime("%d%b%y_%H%M%S") + '.pdf'
    dot.render(output_file_name, view=True)

try:
    generate_graph()
except Exception as e:
    print('Error while generating graph:', str(e)) 
