import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
import sys

from graphviz import Digraph

def generate_graph():
    dot = Digraph(comment='SecureCorp Policy Misconfiguration')
    dot.attr('node', shape='box', style='rounded')
    
    # Define nodes
    dot.node('TemporaryEmployeeRole', 'TemporaryEmployeeRole')
    dot.node('AssistantManagerRole', 'AssistantManagerRole')
    dot.node('ContractAssistantManagerRole', 'ContractAssistantManagerRole')
    dot.node('ManagerRole', 'ManagerRole')
    dot.node('s3://securecorp-public/*', 's3://securecorp-public/*')
    dot.node('s3://securecorp-internal/*', 's3://securecorp-internal/*')
    dot.node('Secrets Database', 'Secrets Database', color='red')
    
    # Define edges
    dot.edge('TemporaryEmployeeRole', 'AssistantManagerRole')
    dot.edge('TemporaryEmployeeRole', 'ContractAssistantManagerRole')
    dot.edge('AssistantManagerRole', 'ManagerRole')
    dot.edge('ContractAssistantManagerRole', 'ManagerRole')
    dot.edge('ManagerRole', 's3://securecorp-public/*')
    dot.edge('ManagerRole', 's3://securecorp-internal/*')
    dot.edge('ManagerRole', 'Secrets Database', color='red')
    dot.edge('AssistantManagerRole', 's3://securecorp-public/*')
    dot.edge('ContractAssistantManagerRole', 's3://securecorp-public/*')
    
    # Add dotted edge for potential violation path
    dot.edge('TemporaryEmployeeRole', 'ManagerRole', style='dotted')
    
    # Add covert channel in case of access violation
    dot.edge('AssistantManagerRole', 'Secrets Database', color='yellow', label='covert channel')
    
    # Generate and save graph in the specified folder
    folder_path = 'D:/TCS/FOC/AWS Paper Runs/Output/'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    timestamp = datetime.datetime.now().strftime('%d%b%y_%H%M%S')
    file_name = 'SecureCorp Policy Misconfiguration ' + timestamp
    dot.format = 'png'
    dot.render(folder_path + file_name)
    
    # Open the generated PNG image
    os.startfile(folder_path + file_name + '.png')
    
try:
    generate_graph()
except Exception as e:
    print('Error:', e)
    sys.exit(1)
