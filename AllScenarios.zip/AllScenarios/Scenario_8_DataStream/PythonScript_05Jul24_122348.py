import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
from graphviz import Digraph
import subprocess
import sys

try:
    # Set current time
    current_time = datetime.datetime.now().strftime("%d%b%Y_%H%M%S")

    # Define the directory path
    directory_path = "D:\\TCS\\FOC\\AWSRuns\\Output\\"

    # File names with date and time format
    file_name_dot = "AWS_Policy_Graph_" + current_time + ".dot"
    file_name_pdf = "AWS_Policy_Graph_" + current_time + ".pdf"
    file_name_png = "AWS_Policy_Graph_" + current_time + ".png"

    # Create a new directed graph
    graph = Digraph('G', filename=directory_path + file_name_dot, format='png')

    # Add a rectangle with the message
    graph.attr('node', shape='rectangle', style='filled', color='lightblue2')
    graph.node('NoCovertChannel', 'No Covert Channel Found')

    # Define node styles
    graph.attr('node', shape='ellipse', style='', color='')

    # Add roles
    graph.node('DataEntryClerkRole')
    graph.node('DataAnalystRole')
    graph.node('DataScientistRole')
    graph.node('FinancialAuditorRole')
    graph.node('SeniorManagerRole')

    # Add principals
    graph.node('Alice')
    graph.node('Charlie')
    graph.node('Eve')
    graph.node('Grace')
    graph.node('Ian')

    # Add resources
    graph.attr('node', shape='cylinder')
    graph.node('DataEntrySys', 'datastream-entry/*')
    graph.node('AnonymizedData', 'datastream-anonymized/*')
    graph.node('RawData', 'datastream-raw/*')
    graph.node('FinancialData', 'datastream-financial/*')

    # Define edges
    # Data Entry Clerk Role Paths
    graph.edge('Alice', 'DataEntryClerkRole', label='1')
    graph.edge('DataEntryClerkRole', 'DataEntrySys')
    graph.edge('DataEntryClerkRole', 'DataAnalystRole', label='2')

    # Data Analyst Role Paths
    graph.edge('Charlie', 'DataAnalystRole', label='1')
    graph.edge('DataAnalystRole', 'AnonymizedData')
    graph.edge('DataAnalystRole', 'DataScientistRole', label='2')

    # Data Scientist Role Paths
    graph.edge('Eve', 'DataScientistRole', label='1')
    graph.edge('DataScientistRole', 'AnonymizedData')
    graph.edge('DataScientistRole', 'RawData')
    graph.edge('DataScientistRole', 'FinancialAuditorRole', label='2')

    # Financial Auditor Role Paths
    graph.edge('Grace', 'FinancialAuditorRole', label='1')
    graph.edge('FinancialAuditorRole', 'FinancialData')
    graph.edge('FinancialAuditorRole', 'SeniorManagerRole', label='2')

    # Senior Manager Role Paths
    graph.edge('Ian', 'SeniorManagerRole', label='1')

    # Save and render the graph to a PDF and PNG
    graph.render(directory=directory_path, view=False)

    # Open the PNG image
    os.startfile(directory_path + file_name_png)

except Exception as e:
    print(str(e))
