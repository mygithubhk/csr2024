import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
import sys
from graphviz import Digraph

try:
    # Create output directory if it does not exist
    output_directory = "D:\\TCS\\FOC\\AWS Paper Runs\\Output\\"
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    # Get current datetime for file naming
    current_datetime = datetime.datetime.now().strftime("%d%b%Y_%H%M%S")
    file_basename = "AeroStreamIAMPolicyViolation_" + current_datetime

    # Initialize Digraph object
    dot = Digraph(comment='AeroStream IAM Policy Violation')

    # Define nodes
    dot.node('Chris', 'Chris (IT Contractor)')
    dot.node('FO_Manager', 'Flight Operations Manager Role')
    dot.node('S3_FlightOps', 'S3 Bucket: aerostream-flight-ops')

    # Define edges
    dot.edge('Chris', 'FO_Manager', '1. AssumeRole', style='dotted')
    dot.edge('FO_Manager', 'S3_FlightOps', '2. Full S3 Access')
    dot.edge('FO_Manager', 'S3_FlightOps', 'covert channel', color='yellow')

    # Save the dot graph in different formats
    output_path_without_extension = os.path.join(output_directory, file_basename)
    dot.render(output_path_without_extension, format='png', cleanup=True)
    dot.render(output_path_without_extension, format='pdf', cleanup=False)
    dot.render(output_path_without_extension, format='dot', cleanup=False)

    # Open the PNG image after execution
    png_file_path = output_path_without_extension + '.png'
    if sys.platform == "win32":
        os.startfile(png_file_path)
    else:
        opener = "open" if sys.platform == "darwin" else "xdg-open"
        os.system(opener + " " + png_file_path)

except Exception as e:
    print(str(e))
