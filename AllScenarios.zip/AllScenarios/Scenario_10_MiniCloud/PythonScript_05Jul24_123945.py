import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
from graphviz import Digraph

# Define the AWS policies as a graph
def create_policy_graph():
    # Create a new directed graph
    dot = Digraph()

    # Add the "No Covert Channel Found" component
    dot.node("No Covert Channel Found", shape="rectangle", style="filled", fillcolor="lightblue")

    # Add nodes and edges for FileViewerRole
    dot.node("FileViewerRole", shape="ellipse")
    dot.node("Alice", shape="box")
    dot.edge("Alice", "FileViewerRole", label="AssumeRole", color="green")
    dot.node("S3 Bucket", shape="box")
    dot.edge("FileViewerRole", "S3 Bucket", label="List/Read", color="blue")

    # Add nodes and edges for FileUploaderRole
    dot.node("FileUploaderRole", shape="ellipse")
    dot.node("Bob", shape="box")
    dot.edge("Bob", "FileUploaderRole", label="AssumeRole", color="green")
    dot.edge("FileUploaderRole", "S3 Bucket", label="Upload", color="blue")

    # Add trust policies
    dot.edge("FileUploaderRole", "FileViewerRole", label="AssumeRole", color="red")
    dot.edge("FileViewerRole", "FileUploaderRole", label="AssumeRole", color="red")

    # Save the graph as a DOT file
    dot.format = "pdf"
    filename = "D:\TCS\FOC\AWSRuns\Output\policy_graph_{}.pdf".format(datetime.datetime.now().strftime("%d%b%y_%H%M%S"))
    dot.render(filename)

    # Convert the DOT file to a PNG image and display it
    os.system('dot -Tpng "{}" -o "{}"'.format(filename, filename.replace(".pdf", ".png")))
    os.system('start "{}"'.format(filename.replace(".pdf", ".png")))

try:
    create_policy_graph()
except Exception as e:
    print("Exception occurred: {}".format(str(e)))
