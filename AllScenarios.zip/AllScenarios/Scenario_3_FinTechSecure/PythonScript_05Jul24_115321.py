import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import graphviz
import datetime

# Define the nodes and edges of the graph
nodes = ['Bob', 'Alice', 'Charlie', 'AllowExpectedPatternsRule', 'API Gateway', 'Sensitive Financial Data']
edges = [('Bob', 'AllowExpectedPatternsRule'), ('Alice', 'API Gateway'), ('Charlie', 'Sensitive Financial Data'), ('AllowExpectedPatternsRule', 'API Gateway'), ('API Gateway', 'Sensitive Financial Data')]

# Define the graph
dot = graphviz.Digraph(comment='Access Violation Graph')
for node in nodes:
    dot.node(node)
for edge in edges:
    dot.edge(edge[0], edge[1])

# Add covert channel to violating path
dot.edge('AllowExpectedPatternsRule', 'API Gateway', color='yellow', label='covert channel')

# Render and save the graph
now = datetime.datetime.now().strftime('%d%b%y_%H%M%S')
filename = 'access_violation_graph_' + now
dot.format = 'png'
dot.render(filename, directory='D:/TCS/FOC/AWS Paper Runs/Output', view=True)
