import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

import datetime
import os
from graphviz import Digraph

try:
    # Create the output directory if it does not exist
    output_dir = "D:\\TCS\\FOC\\AWS Paper Runs\\Output\\"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Generate the timestamp for the filename
    timestamp = datetime.datetime.now().strftime("%d%b%y_%H%M%S")

    # Initialize Digraph object
    dot = Digraph(comment='AWS IAM Policy Violation Graph')

    # Define nodes for the principals
    dot.node('T', 'TemporaryEmployeeRole (Alice)')
    dot.node('A', 'AssistantManagerRole')
    dot.node('C', 'ContractAssistantManagerRole')
    dot.node('M', 'ManagerRole')

    # Define nodes for the resources
    dot.node('PB', 'beanbags-public S3 Bucket', shape='cylinder')
    dot.node('IB', 'beanbags-internal S3 Bucket', shape='cylinder')
    dot.node('SD', 'Secrets Database', shape='cylinder')

    # Define edges for the roles
    dot.edge('T', 'A', label='1', style='dotted')  # Temporary to Assistant
    dot.edge('T', 'C', label='1', style='dotted')  # Temporary to Contract Assistant
    dot.edge('A', 'M', label='2', style='dotted')  # Assistant to Manager
    dot.edge('C', 'M', label='2', style='dotted')  # Contract Assistant to Manager

    # Define access edges
    dot.edge('T', 'PB', label='Allow')
    dot.edge('A', 'IB', label='Allow')
    dot.edge('C', 'IB', label='Allow')
    dot.edge('M', 'SD', label='Allow', color='yellow')  # Manager has legitimate access

    # Define covert channel
    dot.edge('T', 'SD', label='covert channel', color='yellow', style='dashed')

    # Render the graph
    output_filename = f'AWS_IAM_Policy_Violation_{timestamp}'
    dot.format = 'png'
    dot.render(os.path.join(output_dir, output_filename), view=False)

    # Save additional formats
    dot.format = 'pdf'
    dot.render(os.path.join(output_dir, output_filename), view=False)
    dot.format = 'dot'
    dot.render(os.path.join(output_dir, output_filename), view=False)

    # Open the PNG image
    os.startfile(os.path.join(output_dir, f'{output_filename}.png'))

except Exception as e:
    print(e)
